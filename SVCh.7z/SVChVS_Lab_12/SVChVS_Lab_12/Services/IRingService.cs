﻿namespace SVChVS_Lab_12.Services.RingServices
{
    public interface IRingService : IServiceBase<Ring>
    {

    }
}
