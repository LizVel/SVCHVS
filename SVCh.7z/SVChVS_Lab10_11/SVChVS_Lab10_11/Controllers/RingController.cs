﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SVChVS_Lab10_11.Models;
using SVChVS_Lab10_11.Services;
using System;

namespace SVChVS_Lab10_11.Controllers
{
    [ApiController]
    public class RingController : ControllerBase
    {
        private readonly IRingService _welderService;

        public RingController(IRingService welderService)
        {
            _welderService = welderService;
        }

        [HttpGet]
        [Route("[controller]")]
        public IActionResult GetAll()
        {
            try
            {
                var welders = _welderService.GetAll();

                return Ok(welders);
            }
            catch (Exception e)
            {
                return StatusCode(500, $"{e.Message}");
            }
        }

        [HttpPost]
        [Route("[controller]/create")]
        [ProducesResponseType(typeof(Ring), StatusCodes.Status200OK)]
        public IActionResult Create([FromBody] Ring welderForCreate)
        {
            try
            {
                if (welderForCreate is null || !ModelState.IsValid)
                {
                    return BadRequest("Модель не подходит");
                }

                _welderService.Create(welderForCreate);

                return Ok(welderForCreate);
            }
            catch (Exception e)
            {
                return StatusCode(500, $"{e.Message}");
            }
        }

        [HttpPut]
        [Route("[controller]/update")]
        [ProducesResponseType(typeof(Ring), StatusCodes.Status200OK)]
        public IActionResult Update([FromBody] Ring welderForUpdate)
        {
            try
            {
                if (welderForUpdate is null || !ModelState.IsValid)
                {
                    return BadRequest("Модель не подходит");
                }

                _welderService.Update(welderForUpdate.Name, welderForUpdate);

                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(500, $"{e.Message}");
            }
        }

        [HttpDelete]
        [Route("[controller]/delete")]
        [ProducesResponseType(typeof(int), StatusCodes.Status200OK)]
        public IActionResult Delete([FromBody] string RFID)
        {
            try
            {
                _welderService.Remove(RFID);

                return Ok(RFID);
            }
            catch (Exception e)
            {
                return StatusCode(500, $"{e.Message}");
            }
        }
    }
}
