import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Layout } from './Layout';
import './custom.css'
import { RingPage } from './components/RingPage';
import { ErrorForm } from './components/ErrorForm';

export default class App extends Component {
  static displayName = App.name;

  render () {
    return (
        <Layout>
            <Router>
                <Routes>
                    <Route path='/' element={<div></div>} />
                    <Route path='/RingsPage' element={<RingPage />} />
                    <Route path='*' element={<ErrorForm />} />
                </Routes>
            </Router>
      </Layout>
    );
  }
}
