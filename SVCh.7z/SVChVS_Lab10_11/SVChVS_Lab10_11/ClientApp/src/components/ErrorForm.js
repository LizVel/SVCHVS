﻿import React, { Component } from 'react';

export class ErrorForm extends Component {
    static displayName = ErrorForm.name;

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <h1 style={{justifyContent: "center", textAlign:"center", paddingTop:300 }}>Вы перешли по неверной ссылке, вернитесь пожалуйста назад</h1>
        );
    }
}
