﻿namespace SVChVS_Lab10_11.Models
{
    public class Ring
    {
        public string Name { get; set; }
        public string Price { get; set; }
    }
}
