﻿namespace SVChVS_Lab10_11.Services
{
    public interface ISerializer<T>
    {
        void Serialize(T data, string filePath);
    }
}
