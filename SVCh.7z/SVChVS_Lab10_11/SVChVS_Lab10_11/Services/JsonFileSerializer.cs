﻿using System.Text.Json;
using System.IO;
using System.Text.Encodings.Web;
using System.Text.Unicode;

namespace SVChVS_Lab10_11.Services
{
    public class JsonFileSerializer<T> : ISerializer<T>
    {
        public void Serialize(T data, string filePath)
        {
            var options = new JsonSerializerOptions
            {
                Encoder = JavaScriptEncoder.Create(UnicodeRanges.BasicLatin, UnicodeRanges.Cyrillic),
                WriteIndented = true
            };

            using (var streamWriter = new StreamWriter(File.Create(filePath)))
            {
                streamWriter.WriteLine(JsonSerializer.Serialize(data, options));
            }
        }
    }
}
