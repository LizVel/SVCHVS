﻿using System.Text.Json;
using System.IO;

namespace SVChVS_Lab10_11.Services
{
    public class JsonFileDeserializer<T> : IDeserializer<T>
    {
        public T Deserialize(string filePath)
        {
            string dataText = File.ReadAllText(filePath);

            return JsonSerializer.Deserialize<T>(dataText);
        }
    }
}
