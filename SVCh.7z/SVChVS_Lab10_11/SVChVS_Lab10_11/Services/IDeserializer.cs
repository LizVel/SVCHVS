﻿namespace SVChVS_Lab10_11.Services
{
    public interface IDeserializer<T>
    {
        T Deserialize(string filePath);
    }
}
