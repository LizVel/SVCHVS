﻿using SVChVS_Lab10_11.Models;
using System.Collections.Generic;

namespace SVChVS_Lab10_11.Services
{
    public interface IRingService
    {
        void Create(Ring data);
        List<Ring> GetAll();
        void Remove(string name);
        void Update(string name, Ring data);
        int GetIndex(string name);
    }
}
