﻿using SVChVS_Lab10_11.Models;
using System.Collections.Generic;
using System.Linq;

namespace SVChVS_Lab10_11.Services
{
    public class RingService : IRingService
    {
        private readonly ISerializer<List<Ring>> _serializer;
        private readonly IDeserializer<List<Ring>> _deserializer;

        public RingService(ISerializer<List<Ring>> serializer, IDeserializer<List<Ring>> deserializer)
        {
            _serializer = serializer;
            _deserializer = deserializer;
        }

        public void Create(Ring data)
        {
            var rings = _deserializer.Deserialize("Rings.json");

            rings.Add(data);

            _serializer.Serialize(rings, "Rings.json");
        }

        public int GetIndex(string descritpion)
        {
            var bracers = _deserializer.Deserialize("Rings.json");

            for (int i = 0; i < bracers.Count; i++)
            {
                if (bracers[i].Name.Contains(descritpion))
                {
                    return i;
                }
            }

            return 0;
        }

        public List<Ring> GetAll()
        {
            return _deserializer.Deserialize("Rings.json")
                .OrderBy(_ => _.Price)
                .ToList();
        }

        public void Remove(string description)
        {
            var rings = GetAll();

            rings.RemoveAt(GetIndex(description));

            _serializer.Serialize(rings, "Rings.json");
        }

        public void Update(string description, Ring data)
        {
            Remove(description);

            Create(data);
        }
    }
}
