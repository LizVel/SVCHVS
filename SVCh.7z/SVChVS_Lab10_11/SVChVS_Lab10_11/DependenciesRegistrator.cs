﻿using Microsoft.Extensions.DependencyInjection;
using SVChVS_Lab10_11.Models;
using System.Collections.Generic;

namespace SVChVS_Lab10_11.Services
{
    public static class DependenciesRegistrator
    {
        public static void Registrate(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddScoped<IRingService, RingService>();
            serviceCollection.AddScoped<IDeserializer<List<Ring>>, JsonFileDeserializer<List<Ring>>>();
            serviceCollection.AddScoped<ISerializer<List<Ring>>, JsonFileSerializer<List<Ring>>>();
        }
    }
}
